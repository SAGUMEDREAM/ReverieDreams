package cc.thonly.registry_modifier.mixin;

import net.minecraft.class_6862;
import net.minecraft.class_6885;
import net.minecraft.class_7876;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_6885.class_6888.class)
public interface NamedAccessor<T> {
    @Accessor("owner")
    class_7876<T> getOwner();

    @Accessor("tag")
    class_6862<T> getTagKey();

    @Invoker("<init>")
    static <T> class_6885.class_6888<T> callNew(class_7876<T> owner, class_6862<T> tag) {
        throw new AssertionError();
    }
}
