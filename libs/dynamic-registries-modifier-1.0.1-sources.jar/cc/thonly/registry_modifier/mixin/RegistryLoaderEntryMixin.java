package cc.thonly.registry_modifier.mixin;

import cc.thonly.registry_modifier.api.DynamicRegistryManagerCallback;
import com.mojang.serialization.Lifecycle;
import lombok.extern.slf4j.Slf4j;
import net.minecraft.class_7655;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;

@Slf4j
@Mixin(class_7655.class_7657.class)
public class RegistryLoaderEntryMixin {
//    @Inject(method = "getLoader", at = @At("RETURN"), cancellable = true)
//    private static<T> void getLoader(Lifecycle lifecycle, Map<RegistryKey<?>, Exception> errors, CallbackInfoReturnable<RegistryLoader.Loader<T>> cir) {
//        RegistryLoader.Loader<T> loader = cir.getReturnValue();
//        MutableRegistry<T> mutableRegistry = loader.registry();
//        if (mutableRegistry instanceof SimpleRegistry<T> registry) {
//            DynamicRegistryManagerCallback.start(registry);
//        }
////        System.out.println(mutableRegistry.getKey());
//    }
}
